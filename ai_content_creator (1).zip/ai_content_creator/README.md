# AI Content Creator (CT)

Kısa tanıtım videosu içerik üreticileri (YouTube Shorts / TikTok / Reels) için
tek girişli (konu) → tam içerik paketi üreten premium AI stüdyo uygulaması.

## Mimari — Clean Architecture

```
lib/
  core/                      # Paylaşılan, özellikten bağımsız katman
    theme/                   # Renkler, tipografi, ThemeData
    widgets/                 # CtLogo, OutputCard gibi tekrar kullanılan UI
    constants/
  domain/                    # Framework'ten bağımsız iş kuralları
    entities/                # ContentPackage, HookIdea, StoryboardScene
    repositories/            # ContentRepository (soyut sözleşme)
  data/                      # Dış dünya ile konuşan katman
    services/                # MockContentRepository (şimdilik) →
                              #   ileride LlmContentRepository, buraya eklenir
    models/                  # DTO / JSON eşlemeleri (gerçek API bağlanınca)
  presentation/               # UI + state (Provider/ChangeNotifier)
    home/                    # Ana panel — tek konu girişi
    result/                  # Üretim animasyonu + sonuç kartları
    settings/                # Tema, dil, abonelik, API, dışa aktarma
    subscription/            # (hazır klasör) — ödeme/abonelik akışı
    export/                  # (hazır klasör) — PDF/JSON/TXT dışa aktarma
    providers/                # ThemeProvider, LocaleProvider, GenerationProvider
```

**Bağımlılık yönü tek yönlü:** `presentation → domain ← data`. UI hiçbir zaman
`data/services` içeriğini doğrudan bilmez; sadece `domain/repositories`
sözleşmesini bilir. Bu sayede gerçek AI sağlayıcısı (OpenAI, Claude, Gemini,
kendi backend'iniz) `ContentRepository`'yi implemente eden yeni bir sınıfla
takılır — **hiçbir ekran kodu değişmez.**

## Gerçek AI entegrasyonu için sıradaki adım

1. `lib/data/services/mock_content_repository.dart` dosyasındaki
   `MockContentRepository` sınıfının yanına `llm_content_repository.dart`
   oluşturun ve `ContentRepository`'yi implemente edin.
2. Metin alanları (başlık, hook, senaryo, SEO, vb.) için seçtiğiniz LLM'i,
   video prompt alanları için Veo/Kling/Runway uyumlu prompt şablonlarını
   kullanın — uygulama video render etmez, yalnızca üretim promptu üretir.
3. `main.dart` içindeki tek satırı değiştirin:
   ```dart
   Provider<ContentRepository>(create: (_) => LlmContentRepository(...))
   ```

## Genişletme noktaları (hazır klasörler)

- `presentation/subscription/` — RevenueCat/StoreKit/Play Billing akışı
- `presentation/export/` — PDF, TXT, SRT, JSON dışa aktarma
- Yeni bir "modül" (örn. A/B başlık testi, çoklu dil seslendirme) eklemek
  için `presentation/<modul_adi>/` klasörü açıp aynı Provider + Repository
  desenini izleyin.

## Tasarım dili

- Tek monokrom "CT" monogramı (`core/widgets/ct_logo.dart`, CustomPainter ile
  çizili — imaj asseti değil, klişe gradient/robot ikonu yok).
- Tek vurgu rengi (sıcak amber) + neredeyse siyah kanvas; "AI app" klişesi
  olan mor/mavi gradientlerden kaçınıldı.
- Başlıklarda editoryal serif (Fraunces), gövde metinde Inter — teknik
  güven + premium/editoryal his dengesi.
- `flutter_animate` ile kart girişleri, sayfa geçişleri ve üretim ekranındaki
  nefes alan logo animasyonu.

## Çalıştırma

```bash
flutter pub get
flutter run
```

> Not: `MockContentRepository` internet olmadan, sahte gecikmelerle tam bir
> içerik paketi üretir — UI/UX'i uçtan uca test etmek için idealdir.
