import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../domain/entities/content_package.dart';
import '../../domain/repositories/content_repository.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _mode = ThemeMode.dark;
  ThemeMode get mode => _mode;

  ThemeProvider() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('theme_mode');
    if (saved == 'light') _mode = ThemeMode.light;
    if (saved == 'dark') _mode = ThemeMode.dark;
    notifyListeners();
  }

  Future<void> toggle() async {
    _mode = _mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', _mode == ThemeMode.dark ? 'dark' : 'light');
  }
}

class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('tr');
  Locale get locale => _locale;

  void setLocale(Locale locale) {
    _locale = locale;
    notifyListeners();
  }
}

enum GenerationStatus { idle, loading, success, error }

/// Drives the create → result flow. Injected with a [ContentRepository] so
/// the real AI backend can be swapped in without touching the UI layer.
class GenerationProvider extends ChangeNotifier {
  final ContentRepository repository;
  GenerationProvider(this.repository);

  GenerationStatus status = GenerationStatus.idle;
  String progressLabel = '';
  double progress = 0;
  ContentPackage? package;
  String? errorMessage;
  final List<ContentPackage> history = [];

  Future<void> generate(String topic) async {
    status = GenerationStatus.loading;
    progress = 0;
    progressLabel = 'Başlatılıyor…';
    errorMessage = null;
    notifyListeners();

    await for (final event in repository.generate(topic)) {
      if (event is GenerationStep) {
        progress = event.progress;
        progressLabel = event.label;
        notifyListeners();
      } else if (event is GenerationComplete) {
        package = event.package;
        history.insert(0, event.package);
        status = GenerationStatus.success;
        notifyListeners();
      } else if (event is GenerationFailed) {
        errorMessage = event.message;
        status = GenerationStatus.error;
        notifyListeners();
      }
    }
  }

  void reset() {
    status = GenerationStatus.idle;
    package = null;
    progress = 0;
    notifyListeners();
  }
}
