import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../providers/app_providers.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final locale = context.watch<LocaleProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        children: [
          _SectionLabel('Görünüm'),
          _SettingsTile(
            icon: Icons.dark_mode_outlined,
            title: 'Koyu Tema',
            trailing: Switch(
              value: theme.mode == ThemeMode.dark,
              activeThumbColor: AppColors.accent,
              onChanged: (_) => context.read<ThemeProvider>().toggle(),
            ),
          ),
          _SectionLabel('Dil'),
          _SettingsTile(
            icon: Icons.language_outlined,
            title: 'Uygulama Dili',
            subtitle: locale.locale.languageCode == 'tr' ? 'Türkçe' : 'English',
            onTap: () => _showLanguagePicker(context),
          ),
          _SectionLabel('Abonelik'),
          _SettingsTile(
            icon: Icons.workspace_premium_outlined,
            title: 'CT Pro',
            subtitle: 'Sınırsız üretim, öncelikli işleme',
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.14),
                borderRadius: BorderRadius.circular(100),
              ),
              child: const Text('Yükselt', style: TextStyle(color: AppColors.accent, fontSize: 12, fontWeight: FontWeight.w600)),
            ),
            onTap: () {},
          ),
          _SectionLabel('API Ayarları'),
          _SettingsTile(
            icon: Icons.key_outlined,
            title: 'Metin Modeli API Anahtarı',
            subtitle: 'Bağlı değil',
            onTap: () => _showApiKeySheet(context, 'Metin Modeli'),
          ),
          _SettingsTile(
            icon: Icons.movie_creation_outlined,
            title: 'Video Modeli (Veo / Kling)',
            subtitle: 'Bağlı değil',
            onTap: () => _showApiKeySheet(context, 'Video Modeli'),
          ),
          _SectionLabel('Dışa Aktarma'),
          _SettingsTile(
            icon: Icons.ios_share_outlined,
            title: 'Varsayılan Dışa Aktarma Formatı',
            subtitle: 'PDF, TXT, SRT, JSON',
            onTap: () {},
          ),
          _SectionLabel('Hakkında'),
          _SettingsTile(icon: Icons.info_outline, title: 'Sürüm', subtitle: '1.0.0'),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  void _showLanguagePicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            ListTile(
              title: const Text('Türkçe'),
              onTap: () {
                context.read<LocaleProvider>().setLocale(const Locale('tr'));
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('English'),
              onTap: () {
                context.read<LocaleProvider>().setLocale(const Locale('en'));
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showApiKeySheet(BuildContext context, String modelName) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 20, right: 20, top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$modelName Bağlantısı', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 14),
            TextField(
              obscureText: true,
              decoration: const InputDecoration(hintText: 'API anahtarını yapıştır'),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Kaydet')),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 8, left: 4),
      child: Text(text.toUpperCase(), style: Theme.of(context).textTheme.labelSmall?.copyWith(letterSpacing: 0.6)),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  const _SettingsTile({required this.icon, required this.title, this.subtitle, this.trailing, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
      ),
      child: ListTile(
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Icon(icon, size: 20),
        title: Text(title, style: Theme.of(context).textTheme.bodyLarge),
        subtitle: subtitle != null ? Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium) : null,
        trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_right_rounded, size: 18) : null),
      ),
    );
  }
}
