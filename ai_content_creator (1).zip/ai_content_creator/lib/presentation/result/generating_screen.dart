import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/ct_logo.dart';
import '../providers/app_providers.dart';
import 'result_screen.dart';

class GeneratingScreen extends StatelessWidget {
  const GeneratingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GenerationProvider>(
      builder: (context, gen, __) {
        if (gen.status == GenerationStatus.success && gen.package != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => ResultScreen(package: gen.package!)),
            );
          });
        }

        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CtLogo(size: 46).animate(onPlay: (c) => c.repeat(reverse: true)).scaleXY(
                        begin: 0.94,
                        end: 1.04,
                        duration: 1400.ms,
                        curve: Curves.easeInOut,
                      ),
                  const SizedBox(height: 36),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: LinearProgressIndicator(
                      value: gen.progress,
                      minHeight: 4,
                      backgroundColor: AppColors.borderDark,
                      valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                    ),
                  ),
                  const SizedBox(height: 20),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      gen.status == GenerationStatus.error
                          ? (gen.errorMessage ?? 'Bir hata oluştu')
                          : gen.progressLabel,
                      key: ValueKey(gen.progressLabel),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ),
                  if (gen.status == GenerationStatus.error) ...[
                    const SizedBox(height: 20),
                    OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Geri dön'),
                    ),
                  ]
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
