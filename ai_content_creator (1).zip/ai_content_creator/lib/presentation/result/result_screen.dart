import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/output_card.dart';
import '../../domain/entities/content_package.dart';
import '../providers/app_providers.dart';

class ResultScreen extends StatelessWidget {
  final ContentPackage package;
  const ResultScreen({super.key, required this.package});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(package.topic, overflow: TextOverflow.ellipsis),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 40),
        children: [
          OutputCard(
            label: 'Viral Başlık',
            copyText: package.viralTitle,
            animationIndex: 0,
            onRegenerate: () => context.read<GenerationProvider>().generate(package.topic),
            child: Text(package.viralTitle, style: Theme.of(context).textTheme.headlineMedium),
          ),
          OutputCard(
            label: '10 Hook Fikri — En İyisi Seçildi',
            copyText: package.hooks.map((h) => '${h.isSelected ? "★ " : ""}${h.text} (${h.score.toStringAsFixed(0)})').join('\n'),
            animationIndex: 1,
            child: Column(
              children: package.hooks
                  .map((h) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              h.isSelected ? Icons.star_rounded : Icons.star_border_rounded,
                              size: 16,
                              color: h.isSelected ? AppColors.accent : Theme.of(context).textTheme.bodyMedium?.color,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(h.text,
                                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                        fontWeight: h.isSelected ? FontWeight.w600 : FontWeight.w400,
                                      )),
                            ),
                            const SizedBox(width: 6),
                            Text(h.score.toStringAsFixed(0),
                                style: Theme.of(context).textTheme.labelSmall),
                          ],
                        ),
                      ))
                  .toList(),
            ),
          ),
          OutputCard(
            label: 'Senaryo (45–60 sn)',
            copyText: package.script,
            animationIndex: 2,
            child: Text(package.script, style: Theme.of(context).textTheme.bodyLarge),
          ),
          OutputCard(
            label: 'Storyboard & Video Promptları',
            copyText: package.storyboard
                .map((s) => 'Sahne ${s.index} — ${s.title}\nGörsel: ${s.visualDescription}\nPrompt: ${s.videoPrompt}\nSeslendirme: ${s.voiceoverLine}')
                .join('\n\n'),
            animationIndex: 3,
            child: Column(
              children: package.storyboard.map((s) => _SceneTile(scene: s)).toList(),
            ),
          ),
          OutputCard(
            label: 'Seslendirme Metni',
            copyText: package.voiceoverFullText,
            animationIndex: 4,
            child: Text(package.voiceoverFullText, style: Theme.of(context).textTheme.bodyLarge),
          ),
          OutputCard(
            label: 'Altyazı (SRT)',
            copyText: package.srtSubtitles,
            animationIndex: 5,
            child: Text(
              package.srtSubtitles,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontFamily: 'monospace'),
            ),
          ),
          OutputCard(
            label: 'Thumbnail Konsepti',
            copyText: package.thumbnailConcept,
            animationIndex: 6,
            child: Text(package.thumbnailConcept, style: Theme.of(context).textTheme.bodyLarge),
          ),
          OutputCard(
            label: 'Açıklama',
            copyText: package.description,
            animationIndex: 7,
            child: Text(package.description, style: Theme.of(context).textTheme.bodyLarge),
          ),
          OutputCard(
            label: 'SEO Anahtar Kelimeler',
            copyText: package.seoKeywords.join(', '),
            animationIndex: 8,
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: package.seoKeywords.map((k) => _Tag(text: k)).toList(),
            ),
          ),
          OutputCard(
            label: 'Hashtagler',
            copyText: package.hashtags.join(' '),
            animationIndex: 9,
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: package.hashtags.map((k) => _Tag(text: k, accent: true)).toList(),
            ),
          ),
          OutputCard(
            label: 'Çağrı Metni (CTA)',
            copyText: package.callToAction,
            animationIndex: 10,
            child: Text(package.callToAction, style: Theme.of(context).textTheme.bodyLarge),
          ),
        ],
      ),
    );
  }
}

class _SceneTile extends StatelessWidget {
  final StoryboardScene scene;
  const _SceneTile({required this.scene});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.bgSecondaryLight,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 22, height: 22,
                alignment: Alignment.center,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.accent.withOpacity(0.15)),
                child: Text('${scene.index}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.accent)),
              ),
              const SizedBox(width: 8),
              Text(scene.title, style: Theme.of(context).textTheme.titleMedium),
              const Spacer(),
              Text('${scene.duration.inSeconds}s', style: Theme.of(context).textTheme.labelSmall),
            ],
          ),
          const SizedBox(height: 8),
          Text(scene.visualDescription, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 6),
          Text('Prompt: ${scene.videoPrompt}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontStyle: FontStyle.italic)),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final bool accent;
  const _Tag({required this.text, this.accent = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(100),
        color: accent ? AppColors.accent.withOpacity(0.12) : Theme.of(context).cardTheme.color,
        border: Border.all(color: accent ? AppColors.accent.withOpacity(0.4) : AppColors.borderDark),
      ),
      child: Text(text, style: Theme.of(context).textTheme.labelLarge?.copyWith(
            color: accent ? AppColors.accent : null,
            fontWeight: FontWeight.w500,
          )),
    );
  }
}
