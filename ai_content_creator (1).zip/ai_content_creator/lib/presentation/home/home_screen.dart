import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/ct_logo.dart';
import '../providers/app_providers.dart';
import '../result/result_screen.dart';
import '../result/generating_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();

  static const _examples = [
    'The Great Emu War',
    'History of Samurai',
    'How Tesla Started',
    'The Fall of Rome',
    'Chernobyl in 60 Seconds',
  ];

  void _submit(BuildContext context) {
    final topic = _controller.text.trim();
    if (topic.isEmpty) return;
    final gen = context.read<GenerationProvider>();
    _focusNode.unfocus();
    gen.generate(topic);
    Navigator.of(context).push(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, anim, __) => const GeneratingScreen(),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween(begin: const Offset(0, 0.03), end: Offset.zero).animate(anim),
            child: child,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final history = context.watch<GenerationProvider>().history;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const CtLogo(size: 30, showWordmark: true),
                  IconButton(
                    icon: const Icon(Icons.settings_outlined),
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Bugün ne anlatalım?',
                          style: Theme.of(context).textTheme.displayLarge).animate().fadeIn(duration: 400.ms),
                      const SizedBox(height: 6),
                      Text(
                        'Tek bir konu yaz — hook, senaryo, storyboard, video promptları,\nseslendirme, altyazı ve SEO paketini birlikte üretelim.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ).animate().fadeIn(duration: 400.ms, delay: 80.ms),
                      const SizedBox(height: 26),
                      _CreateField(controller: _controller, focusNode: _focusNode, onSubmit: () => _submit(context)),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _examples
                            .map((e) => _ExampleChip(
                                  text: e,
                                  onTap: () {
                                    _controller.text = e;
                                    _controller.selection = TextSelection.collapsed(offset: e.length);
                                  },
                                ))
                            .toList(),
                      ).animate().fadeIn(duration: 400.ms, delay: 160.ms),
                      if (history.isNotEmpty) ...[
                        const SizedBox(height: 34),
                        Text('Son Üretimler', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 12),
                        ...history.take(5).map((p) => _HistoryTile(
                              topic: p.topic,
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => ResultScreen(package: p)),
                              ),
                            )),
                      ],
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: SizedBox(
        width: MediaQuery.of(context).size.width - 44,
        child: ElevatedButton(
          onPressed: () => _submit(context),
          child: const Text('Oluştur'),
        ),
      ).animate().fadeIn(duration: 400.ms, delay: 200.ms).moveY(begin: 12, end: 0),
    );
  }
}

class _CreateField extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final VoidCallback onSubmit;
  const _CreateField({required this.controller, required this.focusNode, required this.onSubmit});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
        color: Theme.of(context).cardTheme.color,
      ),
      padding: const EdgeInsets.fromLTRB(20, 18, 12, 18),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        maxLines: 2,
        minLines: 1,
        textInputAction: TextInputAction.go,
        onSubmitted: (_) => onSubmit(),
        style: Theme.of(context).textTheme.bodyLarge,
        decoration: const InputDecoration(
          border: InputBorder.none,
          hintText: 'ör. "How Tesla Started"',
        ),
      ),
    ).animate().fadeIn(duration: 400.ms, delay: 120.ms);
  }
}

class _ExampleChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _ExampleChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(100),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
        ),
        child: Text(text, style: Theme.of(context).textTheme.bodyMedium),
      ),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  final String topic;
  final VoidCallback onTap;
  const _HistoryTile({required this.topic, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
        ),
        child: Row(
          children: [
            const Icon(Icons.auto_awesome_outlined, size: 16, color: AppColors.accent),
            const SizedBox(width: 12),
            Expanded(child: Text(topic, style: Theme.of(context).textTheme.bodyLarge)),
            const Icon(Icons.chevron_right_rounded, size: 18),
          ],
        ),
      ),
    );
  }
}
