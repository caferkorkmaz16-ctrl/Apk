import '../entities/content_package.dart';

/// Contract for turning a single topic string into a full [ContentPackage].
///
/// This is the one seam the whole app depends on. Swap the implementation
/// (e.g. `OpenAiContentRepository`, `ClaudeContentRepository`,
/// `GeminiContentRepository`) in the DI setup — nothing above this layer
/// changes. This is what makes the module "hazır bir yapı" for future
/// providers/models.
abstract class ContentRepository {
  Stream<GenerationEvent> generate(String topic);
}

/// Progress events emitted while a package is being generated, so the UI
/// can show a premium step-by-step loading state instead of a blank spinner.
sealed class GenerationEvent {
  const GenerationEvent();
}

class GenerationStep extends GenerationEvent {
  final String label; // e.g. "Writing viral title…"
  final double progress; // 0.0 - 1.0
  const GenerationStep(this.label, this.progress);
}

class GenerationComplete extends GenerationEvent {
  final ContentPackage package;
  const GenerationComplete(this.package);
}

class GenerationFailed extends GenerationEvent {
  final String message;
  const GenerationFailed(this.message);
}
