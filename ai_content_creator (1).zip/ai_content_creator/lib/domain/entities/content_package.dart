import 'package:equatable/equatable.dart';

/// A single hook idea considered before the model selects the best one.
class HookIdea extends Equatable {
  final String text;
  final double score; // model-estimated virality score 0-100
  final bool isSelected;

  const HookIdea({required this.text, required this.score, this.isSelected = false});

  @override
  List<Object?> get props => [text, score, isSelected];
}

/// One beat of the storyboard.
class StoryboardScene extends Equatable {
  final int index;
  final String title;
  final String visualDescription;
  final String videoPrompt; // Veo / Kling / Runway-ready prompt
  final String voiceoverLine;
  final String onScreenText;
  final Duration duration;

  const StoryboardScene({
    required this.index,
    required this.title,
    required this.visualDescription,
    required this.videoPrompt,
    required this.voiceoverLine,
    required this.onScreenText,
    required this.duration,
  });

  @override
  List<Object?> get props => [index, title, visualDescription, videoPrompt, voiceoverLine, onScreenText, duration];
}

/// The complete generated content bundle for one topic/request.
class ContentPackage extends Equatable {
  final String id;
  final String topic;
  final DateTime createdAt;

  final String viralTitle;
  final List<HookIdea> hooks; // 10 ideas, one flagged isSelected
  final String script; // 45-60s narration script
  final List<StoryboardScene> storyboard;
  final String voiceoverFullText;
  final String srtSubtitles;
  final String thumbnailConcept;
  final String description;
  final List<String> seoKeywords;
  final List<String> hashtags;
  final String callToAction;

  const ContentPackage({
    required this.id,
    required this.topic,
    required this.createdAt,
    required this.viralTitle,
    required this.hooks,
    required this.script,
    required this.storyboard,
    required this.voiceoverFullText,
    required this.srtSubtitles,
    required this.thumbnailConcept,
    required this.description,
    required this.seoKeywords,
    required this.hashtags,
    required this.callToAction,
  });

  HookIdea get bestHook => hooks.firstWhere((h) => h.isSelected, orElse: () => hooks.first);

  @override
  List<Object?> get props => [id, topic, createdAt, viralTitle, hooks, script, storyboard, voiceoverFullText,
      srtSubtitles, thumbnailConcept, description, seoKeywords, hashtags, callToAction];
}
