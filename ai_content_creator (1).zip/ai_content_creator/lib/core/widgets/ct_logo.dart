import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// The CT monogram.
///
/// Design intent: a single continuous stroke suggesting a "C" that opens
/// into a "T" crossbar — drawn with CustomPainter, not an image asset or
/// off-the-shelf icon. Solid single accent color, no gradient. Scales
/// cleanly from 20px (app bar) to 96px (splash).
class CtLogo extends StatelessWidget {
  final double size;
  final Color? color;
  final bool showWordmark;

  const CtLogo({super.key, this.size = 32, this.color, this.showWordmark = false});

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color strokeColor = color ?? (isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight);

    final mark = SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _CtMarkPainter(color: strokeColor),
      ),
    );

    if (!showWordmark) return mark;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        mark,
        SizedBox(width: size * 0.28),
        Text(
          'CT',
          style: TextStyle(
            fontSize: size * 0.62,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
            color: strokeColor,
          ),
        ),
      ],
    );
  }
}

class _CtMarkPainter extends CustomPainter {
  final Color color;
  const _CtMarkPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final double s = size.shortestSide;
    final Paint stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = s * 0.09
      ..strokeCap = StrokeCap.round;

    final Rect bounds = Rect.fromLTWH(0, 0, s, s);
    final Offset center = bounds.center;
    final double r = s * 0.36;

    // Open "C" arc — 270° sweep, gap facing right.
    final Rect arcRect = Rect.fromCircle(center: center, radius: r);
    canvas.drawArc(arcRect, 0.55, 5.2, false, stroke);

    // "T" crossbar + stem nested inside the C's opening, right side.
    final double barY = center.dy - r * 0.55;
    final double barLeft = center.dx - r * 0.02;
    final double barRight = center.dx + r * 1.05;
    canvas.drawLine(Offset(barLeft, barY), Offset(barRight, barY), stroke);

    final double stemX = (barLeft + barRight) / 2;
    canvas.drawLine(Offset(stemX, barY), Offset(stemX, center.dy + r * 0.65), stroke);
  }

  @override
  bool shouldRepaint(covariant _CtMarkPainter oldDelegate) => oldDelegate.color != color;
}
