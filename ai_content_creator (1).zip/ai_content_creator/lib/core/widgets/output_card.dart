import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:share_plus/share_plus.dart';
import '../theme/app_colors.dart';

/// The card every generated output (title, hooks, script, storyboard scene,
/// etc.) renders in on the result screen. Copy / Share / Regenerate live
/// in a quiet action row so the content itself stays the visual focus.
class OutputCard extends StatelessWidget {
  final String label; // eyebrow, e.g. "VIRAL TITLE"
  final Widget child;
  final String copyText;
  final VoidCallback? onRegenerate;
  final int animationIndex;

  const OutputCard({
    super.key,
    required this.label,
    required this.child,
    required this.copyText,
    this.onRegenerate,
    this.animationIndex = 0,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.fromLTRB(20, 18, 16, 14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label.toUpperCase(),
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppColors.accent,
                        letterSpacing: 1.0,
                      ),
                ),
              ),
              _IconAction(
                icon: Icons.copy_rounded,
                tooltip: 'Kopyala',
                onTap: () {
                  Clipboard.setData(ClipboardData(text: copyText));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Panoya kopyalandı'), duration: Duration(milliseconds: 900)),
                  );
                },
              ),
              _IconAction(
                icon: Icons.ios_share_rounded,
                tooltip: 'Paylaş',
                onTap: () => Share.share(copyText),
              ),
              if (onRegenerate != null)
                _IconAction(icon: Icons.refresh_rounded, tooltip: 'Yeniden üret', onTap: onRegenerate!),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    ).animate(delay: (animationIndex * 60).ms).fadeIn(duration: 320.ms).slideY(begin: 0.04, end: 0);
  }
}

class _IconAction extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  const _IconAction({required this.icon, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Icon(icon, size: 17, color: Theme.of(context).textTheme.bodyMedium?.color),
        ),
      ),
    );
  }
}
