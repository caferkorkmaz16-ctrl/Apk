import 'package:flutter/material.dart';

/// CT — AI Content Creator premium palette.
/// Philosophy: near-black canvas, single confident accent (Signal Amber),
/// restrained neutrals. No cheap purple/blue AI gradients.
class AppColors {
  AppColors._();

  // Core canvas
  static const Color bgPrimaryDark = Color(0xFF0A0A0B);
  static const Color bgSecondaryDark = Color(0xFF141416);
  static const Color surfaceDark = Color(0xFF1C1C1F);
  static const Color surfaceElevatedDark = Color(0xFF232326);

  static const Color bgPrimaryLight = Color(0xFFFAFAFA);
  static const Color bgSecondaryLight = Color(0xFFF2F2F3);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color surfaceElevatedLight = Color(0xFFFFFFFF);

  // Accent — a single, confident signal color (warm amber/gold)
  static const Color accent = Color(0xFFE8A33D);
  static const Color accentMuted = Color(0xFF9C7A45);

  // Text
  static const Color textPrimaryDark = Color(0xFFF5F5F4);
  static const Color textSecondaryDark = Color(0xFFA1A1A6);
  static const Color textTertiaryDark = Color(0xFF6B6B70);

  static const Color textPrimaryLight = Color(0xFF17171A);
  static const Color textSecondaryLight = Color(0xFF57575C);
  static const Color textTertiaryLight = Color(0xFF8B8B90);

  // Semantic
  static const Color success = Color(0xFF3FB27F);
  static const Color error = Color(0xFFE05C5C);
  static const Color warning = Color(0xFFE8A33D);

  // Borders / dividers
  static const Color borderDark = Color(0xFF2A2A2D);
  static const Color borderLight = Color(0xFFE4E4E6);
}
