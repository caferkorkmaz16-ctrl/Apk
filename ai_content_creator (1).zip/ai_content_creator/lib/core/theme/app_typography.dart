import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Display type: 'Fraunces'-like editorial serif for headlines gives the
/// app a distinct, non-generic AI-app feel. Body copy uses 'Inter' for
/// clarity and technical trust.
class AppTypography {
  AppTypography._();

  static TextTheme textTheme(bool isDark) {
    final Color primary = isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight;
    final Color secondary = isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight;

    return TextTheme(
      displayLarge: GoogleFonts.fraunces(
        fontSize: 34, fontWeight: FontWeight.w600, color: primary, letterSpacing: -0.5, height: 1.15,
      ),
      displayMedium: GoogleFonts.fraunces(
        fontSize: 26, fontWeight: FontWeight.w600, color: primary, letterSpacing: -0.3, height: 1.2,
      ),
      headlineMedium: GoogleFonts.inter(
        fontSize: 20, fontWeight: FontWeight.w600, color: primary, letterSpacing: -0.2,
      ),
      titleMedium: GoogleFonts.inter(
        fontSize: 16, fontWeight: FontWeight.w600, color: primary,
      ),
      bodyLarge: GoogleFonts.inter(
        fontSize: 15, fontWeight: FontWeight.w400, color: primary, height: 1.5,
      ),
      bodyMedium: GoogleFonts.inter(
        fontSize: 13.5, fontWeight: FontWeight.w400, color: secondary, height: 1.45,
      ),
      labelLarge: GoogleFonts.inter(
        fontSize: 13, fontWeight: FontWeight.w600, color: primary, letterSpacing: 0.2,
      ),
      labelSmall: GoogleFonts.inter(
        fontSize: 11, fontWeight: FontWeight.w500, color: secondary, letterSpacing: 0.4,
      ),
    );
  }
}
