import 'dart:math';
import 'package:uuid/uuid.dart';
import '../../domain/entities/content_package.dart';
import '../../domain/repositories/content_repository.dart';

/// Local, offline stand-in for the real AI pipeline.
///
/// PRODUCTION NOTE: replace this class with a real implementation (e.g.
/// `LlmContentRepository` in `lib/data/services/llm_content_repository.dart`)
/// that calls your chosen text model for the copy fields (title, hooks,
/// script, SEO, etc.) and your chosen video model (Veo 3 / Kling / Runway)
/// only for the `videoPrompt` strings — this app never renders video itself,
/// it produces prompts + assets for those external generators.
/// Nothing outside this file needs to change: it's injected via
/// [ContentRepository] in `presentation/providers`.
class MockContentRepository implements ContentRepository {
  final _uuid = const Uuid();
  final _rnd = Random();

  @override
  Stream<GenerationEvent> generate(String topic) async* {
    final steps = <String>[
      'Analiz ediliyor: "$topic"',
      'Viral başlık yazılıyor…',
      '10 hook fikri üretiliyor…',
      'En güçlü hook seçiliyor…',
      '45-60 sn senaryo yazılıyor…',
      'Sahne sahne storyboard kuruluyor…',
      'Video üretim promptları hazırlanıyor…',
      'Seslendirme metni & altyazı oluşturuluyor…',
      'Thumbnail konsepti tasarlanıyor…',
      'SEO, hashtag ve açıklama hazırlanıyor…',
    ];

    for (int i = 0; i < steps.length; i++) {
      await Future.delayed(const Duration(milliseconds: 380));
      yield GenerationStep(steps[i], (i + 1) / steps.length);
    }

    try {
      yield GenerationComplete(_buildPackage(topic));
    } catch (e) {
      yield GenerationFailed(e.toString());
    }
  }

  ContentPackage _buildPackage(String topic) {
    final hooks = List.generate(10, (i) {
      final score = 60 + _rnd.nextInt(38).toDouble();
      return HookIdea(text: _hookVariant(topic, i), score: score);
    })..sort((a, b) => b.score.compareTo(a.score));

    final selected = hooks.first;
    final finalHooks = hooks
        .map((h) => HookIdea(text: h.text, score: h.score, isSelected: h == selected))
        .toList();

    final scenes = List.generate(6, (i) => StoryboardScene(
          index: i + 1,
          title: 'Sahne ${i + 1}',
          visualDescription: '$topic konusuna dair sinematik, yüksek kontrastlı görsel an — sahne ${i + 1}.',
          videoPrompt:
              'Cinematic 9:16 vertical shot, $topic, scene ${i + 1}, dramatic lighting, photoreal detail, '
              'shallow depth of field, subtle camera movement, no on-screen text, 5s duration.',
          voiceoverLine: '$topic hakkında sahne ${i + 1} anlatım cümlesi buraya gelecek.',
          onScreenText: i == 0 ? selected.text : '',
          duration: const Duration(seconds: 8),
        ));

    return ContentPackage(
      id: _uuid.v4(),
      topic: topic,
      createdAt: DateTime.now(),
      viralTitle: '$topic: Kimsenin Anlatmadığı Gerçek',
      hooks: finalHooks,
      script: _mockScript(topic, selected.text),
      storyboard: scenes.toList(),
      voiceoverFullText: scenes.map((s) => s.voiceoverLine).join(' '),
      srtSubtitles: _mockSrt(scenes.toList()),
      thumbnailConcept: '$topic temalı, yüksek kontrast, tek net yüz/obje odaklı, kalın sans-serif '
          '3-4 kelimelik başlık, kırmızı/sarı vurgu rengiyle dikkat çeken thumbnail kompozisyonu.',
      description: '$topic konusunu 60 saniyede anlatan bu videoda en çarpıcı detayları keşfedin. '
          'Beğenmeyi ve takip etmeyi unutmayın!',
      seoKeywords: [topic, '$topic tarihi', '$topic gerçekleri', '$topic belgesel', 'kısa tarih'],
      hashtags: ['#${topic.replaceAll(' ', '')}', '#shorts', '#tarih', '#viral', '#keşfet'],
      callToAction: 'Devamı için takip et — her hafta yeni bir hikaye!',
    );
  }

  String _hookVariant(String topic, int i) {
    const templates = [
      'Kimse sana $topic hakkında bunu anlatmadı…',
      '$topic\'in gerçek hikayesi düşündüğünden çok daha çılgın.',
      '3 dakikada $topic — ve son 10 saniye seni şaşırtacak.',
      '$topic başladığında kimse bunun nasıl biteceğini bilmiyordu.',
      'Eğer $topic\'i biliyorum sanıyorsan, yanılıyorsun.',
      '$topic: tarihin en absürt anlarından biri.',
      'Bu video $topic hakkındaki her şeyi değiştirecek.',
      '$topic\'in perde arkasında olanlar inanılmaz.',
      '60 saniyede $topic — atlama, her saniye önemli.',
      '$topic hakkında söylenmeyen o detay.',
    ];
    return templates[i % templates.length];
  }

  String _mockScript(String topic, String hook) {
    return '''
[HOOK - 0:00-0:03]
$hook

[SETUP - 0:03-0:15]
$topic, ilk bakışta basit görünen ama aslında beklenmedik dönüşlerle dolu bir hikaye. Her şey küçük bir kıvılcımla başladı.

[GELİŞME - 0:15-0:40]
Olaylar hızla gelişti. Taraflar arasındaki gerilim büyüdü ve sonuç kimsenin tahmin edemeyeceği bir noktaya evrildi.

[DORUK NOKTASI - 0:40-0:52]
İşte bu an, $topic'i unutulmaz kılan an — beklenmedik, çarpıcı ve bir o kadar da öğretici.

[KAPANIŞ / CTA - 0:52-1:00]
Bu hikaye seni şaşırttıysa, devamı için takip etmeyi unutma.
''';
  }

  String _mockSrt(List<StoryboardScene> scenes) {
    final buffer = StringBuffer();
    int start = 0;
    for (int i = 0; i < scenes.length; i++) {
      final end = start + scenes[i].duration.inSeconds;
      buffer.writeln('${i + 1}');
      buffer.writeln('${_fmt(start)} --> ${_fmt(end)}');
      buffer.writeln(scenes[i].voiceoverLine);
      buffer.writeln();
      start = end;
    }
    return buffer.toString().trim();
  }

  String _fmt(int seconds) {
    final d = Duration(seconds: seconds);
    final mm = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final ss = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '00:$mm:$ss,000';
  }
}
