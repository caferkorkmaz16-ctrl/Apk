import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'data/services/mock_content_repository.dart';
import 'domain/repositories/content_repository.dart';
import 'presentation/home/home_screen.dart';
import 'presentation/providers/app_providers.dart';

void main() {
  runApp(const CtApp());
}

class CtApp extends StatelessWidget {
  const CtApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        // Swap MockContentRepository for a real LLM-backed implementation
        // (see lib/data/services/mock_content_repository.dart) without
        // touching any UI code.
        Provider<ContentRepository>(create: (_) => MockContentRepository()),
        ChangeNotifierProvider(
          create: (ctx) => GenerationProvider(ctx.read<ContentRepository>()),
        ),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          return MaterialApp(
            title: 'AI Content Creator',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: themeProvider.mode,
            home: const HomeScreen(),
          );
        },
      ),
    );
  }
}
